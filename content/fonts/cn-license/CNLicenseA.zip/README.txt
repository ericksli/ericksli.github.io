CN License A by Eric Li
http://eric.swiftzer.net/
