Highway Signage by Eric Li
http://eric.swiftzer.net/
